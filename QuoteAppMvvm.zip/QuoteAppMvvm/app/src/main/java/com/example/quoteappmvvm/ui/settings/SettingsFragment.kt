package com.example.quoteappmvvm.ui.settings
import androidx.fragment.app.Fragment

class SettingsFragment : Fragment() {
}