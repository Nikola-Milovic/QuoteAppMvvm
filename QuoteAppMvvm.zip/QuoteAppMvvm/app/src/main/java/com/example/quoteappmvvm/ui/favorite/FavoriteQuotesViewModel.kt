package com.example.quoteappmvvm.ui.favorite

import androidx.lifecycle.ViewModel;

class FavoriteQuotesViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
